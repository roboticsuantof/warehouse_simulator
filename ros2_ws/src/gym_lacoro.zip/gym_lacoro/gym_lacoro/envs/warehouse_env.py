from typing import Optional
import gymnasium as gym
import rclpy
import numpy as np
from gym_lacoro.warehouse_env_node import WarehouseEnvNode

class WarehouseEnvContinuous(gym.Env):

    def __init__(self,
        max_speed_lin: float = 0.6,  #  meters / sec
        max_speed_ang: float = 1.0,  #  radians / sec
        step_time: float = 0.1
        ):
        self.max_speed_lin = max_speed_lin  #  v = meters / sec
        self.max_speed_ang = max_speed_ang  #  omega = radians / sec
        self.step_time = step_time

        # Acción Continua: [Velocidad Lineal (0 a 0.6), Velocidad Angular (-1.0 a 1.0)]
        self.action_space = gym.spaces.Box(
            low=np.array([0.0, -max_speed_ang]), 
            high=np.array([max_speed_lin, max_speed_ang]), 
            dtype=np.float32
        )
        
        # TODO: Define what the agent can observe
        self.observation_space = gym.spaces.Dict(
            {
                "odometry": gym.spaces.Box(0, float("inf"), shape=(5,), dtype=int),   # [x, y] coordinates
                "imu": gym.spaces.Box(0, float("inf"), shape=(2,), dtype=int),  # [x, y] coordinates
                "lidar": gym.spaces.Box(0, float("inf"), shape=(920,), dtype=int),  # [x, y] coordinates
                "target": gym.spaces.Box(0, float("inf"), shape=(2,), dtype=int),  # [x, y] coordinates
            }
        )

        # ROS
        # 1. Iniciar Nodo ROS interno
        if not rclpy.ok():
            rclpy.init()
        self.node = WarehouseEnvNode()

    def _get_obs(self):
        """Convert internal state to observation format.

        Returns:
            dict: Observation with agent and target positions
        """
        return {
            "odometry": np.array(self.node.state['odometry']),
            "imu": np.array(self.node.state['imu']),
            "lidar": np.array(self.node.state['lidar']),
            "target": np.array(self.node.state['target']),
            }

    def _get_info(self):
        """Compute auxiliary information for debugging.

        Returns:
            dict: Info with distance between agent and target
        """
        return {
            "distance": np.linalg.norm(
                self._agent_location - self._target_location, ord=1
            )
        }
    
    def perform_action(self, action):
        # manda accion y spin
        self.node.send_velocity_command(action[0], action[1])
        rclpy.spin_once(self.node, timeout_sec=self.step_time)

    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        """Start a new episode.

        Args:
            seed: Random seed for reproducible episodes
            options: Additional configuration (unused in this example)

        Returns:
            tuple: (observation, info) for the initial state
        """
        # IMPORTANT: Must call this first to seed the random number generator
        super().reset(seed=seed)

        # stop action
        self.perform_action([0, 0])

        # options for start point
        # TODO: Initial position

        # Randomly place the agent anywhere on the grid
        self._agent_location = self.np_random.integers(0, self.size, size=2, dtype=int)

        # Randomly place target, ensuring it's different from agent position
        self._target_location = self._agent_location
        while np.array_equal(self._target_location, self._agent_location):
            self._target_location = self.np_random.integers(
                0, self.size, size=2, dtype=int
            )

        observation = self._get_obs()
        info = self._get_info()

        return observation, info

    def compute_reward(self):
        """
        The challenge does not impose a fixed reward function, but typical components may include:
        - Positive reward for reaching pickup or delivery points.
        - Negative reward for collisions (especially with actors).
        - Penalties for large deviations from the shortest path.
        - Time penalty to encourage efficient trajectories.
        - Optional: Safety margin rewards for maintaining a safe distance to actors.
        """
        return 1
        
    def check_terminal_state(self):
        """
        7.3 Episode Termination Conditions.
        An episode terminates when any of the following occurs:
            - The robot completes the predefined number of deliveries.
            - A collision with a human actor occurs (episode is invalid for scoring).
            - Optional: The robot is detected as “stuck” (no progress after a certain time).
        return terminated, truncated
        """
        return False, False

    def check_tolerance(self):
        """
        7.5 Tolerance Objective
        The tolerance thresholds that must be considered for evaluating the agent’s behavior in the environment are:
        - Distance to obstacles: 0.5 m. Any distance smaller than this value is considered a collision.
        - Distance to actors: 0.7 m. Any distance smaller than this value is considered an incident.
        - Distance to goal: 0.3 m. A distance greater than this value is considered as not having reached the goal.
        """
        pass

    def step(self, action):
        """Execute one timestep within the environment.

        Args:
            action: The action to take (0-3 for directions)

        Returns:
            tuple: (observation, reward, terminated, truncated, info)
        """
        self.perform_action(action)

        # Check if agent reached the target
        terminated, truncated = self.check_terminal_state()

        # Simple reward structure: +1 for reaching target, 0 otherwise
        # Alternative: could give small negative rewards for each step to encourage efficiency
        reward = self.compute_reward()

        observation = self._get_obs()
        info = self._get_info()

        return observation, reward, terminated, truncated, info
